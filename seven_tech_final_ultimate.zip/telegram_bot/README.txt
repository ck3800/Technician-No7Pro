🤖 七号技师 Telegram Bot 控制器

需要设置环境变量：
TG_API_ID
TG_API_HASH
TG_BOT_TOKEN

支持指令：
/start
/send groupX
/status

运行方式：
python telegram_bot/bot_handler.py
