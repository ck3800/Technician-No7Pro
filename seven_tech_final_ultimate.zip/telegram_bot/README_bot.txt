🤖 七号技师 Bot 控制模块说明

指令支持：
/send groupA    → 触发群发 groupA
/status         → 查询任务执行状态

接入方式：
1. 启动 bot_handler.py
2. 将 Token 写入环境变量 TG_BOT_TOKEN
3. Bot 启动后接收消息并调用后端任务

