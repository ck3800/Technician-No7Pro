# 启动 Web 应用（占位）
from app import app
app.run()
